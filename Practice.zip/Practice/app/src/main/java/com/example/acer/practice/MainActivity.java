package com.example.acer.practice;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText e;
    String data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e = findViewById(R.id.editText);

        Button btn = findViewById(R.id.btnOK);

    }

    public void btnPressed(View view)
    {
        Log.d("SAGAR", "btn");
        data = e.getText().toString();

        Log.d("SAGAR", "data is " +data);

        Intent i = new Intent(MainActivity.this, Main2Activity.class);
        i.putExtra("SAGAR",data);
        startActivity(i);


    }


}
